Solution to the first homework assignment of CS520 - Introduction to AI.
By Malihe Alikhani and Ana Echavarria.

To compile and run use:
g++ -Wall main.cpp a_star_search.cpp cell_priority_queue.cpp -o search.bin && ./search.bin
